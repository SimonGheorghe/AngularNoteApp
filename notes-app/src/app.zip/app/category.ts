export interface Category {
    name: string;
    id: string;
  }