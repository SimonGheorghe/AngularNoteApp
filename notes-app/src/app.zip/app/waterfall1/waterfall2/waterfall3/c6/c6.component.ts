import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c6',
  templateUrl: './c6.component.html',
  styleUrls: ['./c6.component.scss']
})
export class C6Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
