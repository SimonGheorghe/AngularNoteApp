export class textList{
    text:string;
    id:number;
}